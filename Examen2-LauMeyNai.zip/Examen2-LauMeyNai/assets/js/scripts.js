// Declaramos variables
var operacion = "";
var numeros = [];
var operadores = [];
 
function init() {
  // Variables
  let pi = document.getElementById('pi');
  let parentesisAbrir = document.getElementById('parentesisAbrir');
  let parentesisCerrar = document.getElementById('parentesisCerrar');
  let raiz = document.getElementById('raiz');
  let log = document.getElementById('log');
  let ln = document.getElementById('ln');
  let sen = document.getElementById('sen');
  let cos = document.getElementById('cos');
  let tan = document.getElementById('tan');
  let abs = document.getElementById('abs');
  let porcentaje = document.getElementById('porcentaje');
  let exp = document.getElementById('exp');
  let resultado = document.getElementById('resultado');
  let reset = document.getElementById('reset');
  let suma = document.getElementById('suma');
  let resta = document.getElementById('resta');
  let multiplicacion = document.getElementById('multiplicacion');
  let division = document.getElementById('division');
  let igual = document.getElementById('igual');
  let uno = document.getElementById('uno');
  let dos = document.getElementById('dos');
  let tres = document.getElementById('tres');
  let cuatro = document.getElementById('cuatro');
  let cinco = document.getElementById('cinco');
  let seis = document.getElementById('seis');
  let siete = document.getElementById('siete');
  let ocho = document.getElementById('ocho');
  let nueve = document.getElementById('nueve');
  let cero = document.getElementById('cero');
 
  // Eventos de click para números
  uno.onclick = function (e) { resultado.textContent = resultado.textContent + "1"; }
  dos.onclick = function (e) { resultado.textContent = resultado.textContent + "2"; }
  tres.onclick = function (e) { resultado.textContent = resultado.textContent + "3"; }
  cuatro.onclick = function (e) { resultado.textContent = resultado.textContent + "4"; }
  cinco.onclick = function (e) { resultado.textContent = resultado.textContent + "5"; }
  seis.onclick = function (e) { resultado.textContent = resultado.textContent + "6"; }
  siete.onclick = function (e) { resultado.textContent = resultado.textContent + "7"; }
  ocho.onclick = function (e) { resultado.textContent = resultado.textContent + "8"; }
  nueve.onclick = function (e) { resultado.textContent = resultado.textContent + "9"; }
  cero.onclick = function (e) { resultado.textContent = resultado.textContent + "0"; }
 
  // Eventos de click para operadores
  suma.onclick = function (e) { agregarOperacion("+"); }
  resta.onclick = function (e) { agregarOperacion("-"); }
  multiplicacion.onclick = function (e) { agregarOperacion("*"); }
  division.onclick = function (e) { agregarOperacion("/"); }
  igual.onclick = function (e) { resolver(); }
  reset.onclick = function (e) { resetear(); }
  sen.onclick = function (e) { agregarOperacion("sin"); };
  cos.onclick = function (e) { agregarOperacion("cos"); };
  tan.onclick = function (e) { agregarOperacion("tan"); };
  log.onclick = function (e) { agregarOperacion("log"); };
  ln.onclick = function (e) { agregarOperacion("ln"); };
  raiz.onclick = function (e) { agregarOperacion("raiz"); };
  abs.onclick = function (e) { agregarOperacion("abs"); };
  exp.onclick = function (e) { agregarOperacion("exp"); };
  
  pi.onclick = function (e) { resultado.textContent = Math.PI; }
 
  parentesisAbrir.onclick = function (e) { resultado.textContent = resultado.textContent + "("; }
 
  parentesisCerrar.onclick = function (e) { resultado.textContent = resultado.textContent + ")"; }
 
  porcentaje.onclick = function (e) {
    let numero = parseFloat(resultado.textContent);
    let porcentajeValor = prompt("Ingrese el porcentaje:");
    if (porcentajeValor !== null && !isNaN(porcentajeValor)) {
      resultado.textContent = (numero * parseFloat(porcentajeValor)) / 100;
    } else {
      alert("Porcentaje no válido.");
    }
  };
}
 
function agregarOperacion(op) {
  let currentValue = parseFloat(resultado.textContent);
  // Si es una función matemática, se evalúa inmediatamente
  if (["sin", "cos", "tan", "log", "ln", "raiz", "abs", "exp"].includes(op)) {
    if (op === "sin") {
      resultado.textContent = Math.sin(currentValue * (Math.PI / 180)); // Convertir de grados a radianes
    } else if (op === "cos") {
      resultado.textContent = Math.cos(currentValue * (Math.PI / 180)); // Convertir de grados a radianes
    } else if (op === "tan") {
      resultado.textContent = Math.tan(currentValue * (Math.PI / 180)); // Convertir de grados a radianes
    } else if (op === "log") {
      resultado.textContent = Math.log10(currentValue);
    } else if (op === "ln") {
      resultado.textContent = Math.log(currentValue);
    } else if (op === "raiz") {
      resultado.textContent = Math.sqrt(currentValue);
    } else if (op === "abs") {
      resultado.textContent = Math.abs(currentValue);
    } else if (op === "exp") {
      resultado.textContent = Math.exp(currentValue);
    }
  } else {
    // Si no es una función, agregar el número y operador
    numeros.push(currentValue);
    operadores.push(op);
    limpiar();
  }
}
 
function limpiar() {
  resultado.textContent = "";
}
 
function resetear() {
  resultado.textContent = "";
  numeros = [];
  operadores = [];
}
 
function resolver() {
  numeros.push(parseFloat(resultado.textContent));
  let res = calcularResultado();
  resetear();
  resultado.textContent = res;
}
 
function calcularResultado() {
  // Primero multiplicaciones y divisiones
  while (operadores.includes("*") || operadores.includes("/")) {
    for (let i = 0; i < operadores.length; i++) {
      if (operadores[i] === "*") {
        numeros[i] = numeros[i] * numeros[i + 1];
        numeros.splice(i + 1, 1);
        operadores.splice(i, 1);
        break;
      } else if (operadores[i] === "/") {
        numeros[i] = numeros[i] / numeros[i + 1];
        numeros.splice(i + 1, 1);
        operadores.splice(i, 1);
        break;
      }
    }
  }
 
  // Luego sumas y restas
  while (operadores.length > 0) {
    if (operadores[0] === "+") {
      numeros[0] = numeros[0] + numeros[1];
    } else if (operadores[0] === "-") {
      numeros[0] = numeros[0] - numeros[1];
    }
    numeros.splice(1, 1);
    operadores.splice(0, 1);
  }
 
  return numeros[0];
}
 
init();